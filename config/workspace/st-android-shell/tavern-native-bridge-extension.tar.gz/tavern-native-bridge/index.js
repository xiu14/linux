(() => {
    const MODULE_ID = 'third-party/tavern-native-bridge';
    const MODULE_NAME = 'Tavern Native Bridge';
    const RETRY_INTERVAL_MS = 500;
    const MAX_ATTACH_ATTEMPTS = 60;
    const STREAMING_THROTTLE_MS = 1200;

    if (typeof window === 'undefined') return;

    const runtime = window.__tavernNativeBridgeRuntime ??= {
        initialized: false,
        listenersAttached: false,
        pendingHooksInstalled: false,
        scrollHooksInstalled: false,
        attempts: 0,
        timer: null,
        isGenerating: false,
        hasContentStarted: false,
        lastStreamingAt: 0,
        preContentBuffer: '',
    };

    if (runtime.initialized) {
        window.__tavernNativeBridgeExtensionReady = true;
        return;
    }

    runtime.initialized = true;
    window.__tavernNativeBridgeExtensionReady = true;

    function emit(name, payload = {}) {
        try {
            const bridge = window.AndroidBridge;
            if (!bridge || typeof bridge.postEvent !== 'function') return false;

            const eventPayload = {
                source: MODULE_ID,
                at: Date.now(),
                href: location.href,
                characterName: getCharacterName(),
                ...payload,
            };

            bridge.postEvent(String(name), JSON.stringify(eventPayload));
            return true;
        } catch (error) {
            console.warn(`[${MODULE_NAME}] emit failed`, error);
            return false;
        }
    }

    function getContext() {
        try {
            return window.SillyTavern?.getContext?.() || null;
        } catch {
            return null;
        }
    }

    function getEventTypes(context) {
        return context?.eventTypes || context?.event_types || {};
    }

    function getCharacterName() {
        try {
            const context = getContext();
            const id = context?.characterId;
            const character = context?.characters?.[id];
            return (character && (character.name || character.avatar)) || '';
        } catch {
            return '';
        }
    }

    function hasPendingInput() {
        try {
            const input = document.querySelector('#send_textarea');
            const value = String(input?.value || '').trim();
            return Boolean(value && value.charAt(0) !== '/');
        } catch {
            return false;
        }
    }

    function emitPending(source) {
        const now = Date.now();
        if (runtime.lastPendingAt && now - runtime.lastPendingAt < 1200) return;
        if (!hasPendingInput()) return;

        runtime.lastPendingAt = now;
        emit('generation_pending', {
            source: source || 'unknown',
            at: now,
        });
    }

    function installPendingHooks() {
        if (runtime.pendingHooksInstalled || typeof document === 'undefined') return;
        runtime.pendingHooksInstalled = true;

        function onSendButtonIntent(event) {
            const target = event.target?.closest?.('#send_but');
            if (target) emitPending(`send_button_${event.type}`);
        }

        document.addEventListener('touchstart', onSendButtonIntent, { capture: true, passive: true });
        document.addEventListener('pointerdown', onSendButtonIntent, { capture: true, passive: true });
        document.addEventListener('mousedown', onSendButtonIntent, true);
        document.addEventListener('click', onSendButtonIntent, true);
    }

    function scrollChatToLatest() {
        try {
            const chat = document.querySelector('#chat');
            if (!chat) return;

            const lastMessage = document.querySelector('#chat .mes:last-child');
            if (lastMessage && typeof lastMessage.scrollIntoView === 'function') {
                lastMessage.scrollIntoView({ block: 'end', inline: 'nearest', behavior: 'auto' });
            }

            chat.scrollTop = chat.scrollHeight;
        } catch (error) {
            console.warn(`[${MODULE_NAME}] scroll to latest failed`, error);
        }
    }

    function scheduleScrollChatToLatest(reason) {
        try {
            clearTimeout(runtime.scrollTimer);
            runtime.lastScrollReason = reason || 'unknown';
            runtime.scrollTimer = setTimeout(() => {
                requestAnimationFrame(scrollChatToLatest);
                setTimeout(scrollChatToLatest, 80);
                setTimeout(scrollChatToLatest, 250);
                setTimeout(scrollChatToLatest, 650);
            }, 80);
        } catch (error) {
            console.warn(`[${MODULE_NAME}] schedule scroll failed`, error);
        }
    }

    function installChatScrollHooks(context, eventTypes) {
        if (runtime.scrollHooksInstalled || !eventTypes.CHAT_CHANGED) return;
        runtime.scrollHooksInstalled = true;
        window.__stNativeScrollChatToLatest = scrollChatToLatest;
        context.eventSource.on(eventTypes.CHAT_CHANGED, () => {
            scheduleScrollChatToLatest('chat_changed');
        });
    }

    function markContentStarted(text, reason) {
        if (runtime.hasContentStarted) return;
        runtime.hasContentStarted = true;
        emit('generation_content_started', {
            reason: reason || 'content',
            length: String(text || '').length,
        });
    }

    function updatePreContentState(text) {
        const value = String(text || '').trim();
        if (!value) return;
        runtime.preContentBuffer = (runtime.preContentBuffer + value.toLowerCase()).slice(-8000);
    }

    function hasContentTag() {
        return /<\s*content\b[^>]*>/i.test(runtime.preContentBuffer);
    }

    function attachListeners(context, eventTypes) {
        if (runtime.listenersAttached) return true;
        if (!context?.eventSource || !eventTypes.GENERATION_STARTED) return false;

        runtime.listenersAttached = true;

        context.eventSource.on(eventTypes.GENERATION_STARTED, (type, params, dryRun) => {
            if (dryRun) return;
            runtime.isGenerating = true;
            runtime.hasContentStarted = false;
            runtime.preContentBuffer = '';
            runtime.lastStreamingAt = 0;
            emit('generation_started', {
                type: type || 'normal',
                params: params || null,
            });
        });

        if (eventTypes.STREAM_TOKEN_RECEIVED) {
            context.eventSource.on(eventTypes.STREAM_TOKEN_RECEIVED, (text) => {
                if (!runtime.isGenerating) return;

                const value = String(text || '');
                if (!runtime.hasContentStarted) {
                    updatePreContentState(value);
                    if (hasContentTag()) {
                        markContentStarted(value, 'content_tag');
                    }
                }

                if (!runtime.hasContentStarted) return;

                const now = Date.now();
                if (now - runtime.lastStreamingAt < STREAMING_THROTTLE_MS) return;
                runtime.lastStreamingAt = now;
                emit('generation_streaming', {
                    length: value.length,
                });
            });
        }

        if (eventTypes.GENERATION_ENDED) {
            context.eventSource.on(eventTypes.GENERATION_ENDED, (messageId) => {
                runtime.isGenerating = false;
                runtime.hasContentStarted = false;
                runtime.preContentBuffer = '';
                emit('generation_ended', {
                    messageId,
                });
            });
        }

        if (eventTypes.GENERATION_STOPPED) {
            context.eventSource.on(eventTypes.GENERATION_STOPPED, () => {
                runtime.isGenerating = false;
                runtime.hasContentStarted = false;
                runtime.preContentBuffer = '';
                emit('generation_stopped');
            });
        }

        return true;
    }

    function attach() {
        try {
            installPendingHooks();

            const context = getContext();
            const eventTypes = getEventTypes(context);
            if (!context?.eventSource || !eventTypes) return false;

            installChatScrollHooks(context, eventTypes);
            const attached = attachListeners(context, eventTypes);
            if (attached) {
                emit('st_bridge_ready', {
                    bridge: MODULE_ID,
                    version: '0.1.0',
                });
            }
            return attached;
        } catch (error) {
            console.warn(`[${MODULE_NAME}] attach failed`, error);
            return false;
        }
    }

    function start() {
        if (attach()) return;

        runtime.timer = setInterval(() => {
            runtime.attempts += 1;
            if (attach() || runtime.attempts >= MAX_ATTACH_ATTEMPTS) {
                clearInterval(runtime.timer);
                runtime.timer = null;
            }
        }, RETRY_INTERVAL_MS);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, { once: true });
    } else {
        start();
    }
})();
